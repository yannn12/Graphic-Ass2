#pragma once

 
#include "Object.h"
#include <vector>


class Scene
{

	

public:

	Scene();
	~Scene();
	
	std::vector <Object*> objects;


};



