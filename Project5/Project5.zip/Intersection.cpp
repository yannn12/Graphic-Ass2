#include "Intersection.h"


Intersection::Intersection(float param, Object* ob) : t(param), object(ob)
{

}
Intersection::~Intersection()
{

}