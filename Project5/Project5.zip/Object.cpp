#include "Object.h"

Vec Object::getColor(Vector3f& point){

	return color;
}