#pragma once
#include "Vector3f.h"

// Global Const



const Vector3f BACKGROUND_COLOR(0, 0, 0);