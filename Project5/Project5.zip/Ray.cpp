#include "Ray.h"


Ray::Ray(Vec &_p, Vec &_v) : Line(_p, _v)
{
	
}

Ray::~Ray()
{}
